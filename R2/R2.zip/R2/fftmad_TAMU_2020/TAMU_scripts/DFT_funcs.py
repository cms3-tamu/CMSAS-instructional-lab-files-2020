#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 19 11:25:48 2019

@author: javierseguradoescudero
"""

import numpy as np

def dft(f):
    """Brute-force DFT"""
    N=len(f)
    n=range(N)
    ns=range(0,1+(N-1)/2)+range(-(N-1)/2,0)
    ft=np.zeros(N,dtype=complex)
    for k in ns:
        i=0
        for n in ns:        
            ft[k]+=f[i]*np.exp(-1j*2*np.pi*k*n/N)
            i+=1
    return ft

def idft(f): 
    """Brute-force IDFT"""
    N=len(f)
    n=range(N)
    ns=range(0,1+(N-1)/2)+range(-(N-1)/2,0)
    fp=np.zeros(N,dtype=complex)
    for k in ns:
        i=0
        for n in ns:        
            fp[k]=f[i]*np.exp(1j*2*np.pi*k*n/N)/N
            i+=1
    return fp   

def dft_v2(f):
    """Brute-force DFT, efficient"""
    N=len(f)
    ns=range(0,1+(N-1)/2)+range(-(N-1)/2,0)
    ft=np.zeros(N,dtype=complex)
    for k in ns:
        ft[k]=np.dot(f,np.exp(-1j*2*np.pi*k*np.array(ns)/N))
    return ft

    
def idft_v2(f):
    """Brute-force DFT, efficient"""
    N=len(f)
    ns=range(0,1+(N-1)/2)+range(-(N-1)/2,0)
    fp=np.zeros(N,dtype=complex)
    for k in ns:
        fp[k]=np.dot(f,np.exp(1j*2*np.pi*k*np.array(ns)/N))/N
    return fp

def fft_cooley(f):
    """A recursive implementation of the 1D Cooley-Tukey FFT, n-power of 2!!"""
    f = np.asarray(f, dtype=float)
    N = len(f)
    ns=np.array(range(0,N/2)+range(-N/2,0))
    if(N<=2):
        return np.array([f[0]+f[1],f[0]-f[1]])	 
    else:
        f_even = fft_cooley(f[::2])
        f_odd = fft_cooley(f[1::2])
        factor = np.exp(-2j * np.pi * ns / N)
        return np.concatenate([f_even + factor[:N / 2] * f_odd, f_even + factor[N / 2:] * f_odd])

def ifft_cooley(f):
    """A recursive implementation of the 1D Cooley-Tukey FFT, n-power of 2!!"""
    f = np.asarray(f, dtype=float)
    N = len(f)
    ns=np.array(range(0,N/2)+range(-N/2,0))
    if(N<=2):
        return np.array([f[0]+f[1],f[0]-f[1]])/2
    else:
        f_even = ifft_cooley(f[::2])
        f_odd = ifft_cooley(f[1::2])
        factor = np.exp(2j * np.pi * ns / N)
        return np.concatenate([f_even + factor[:N / 2] * f_odd, f_even + factor[N / 2:] * f_odd])/2.

