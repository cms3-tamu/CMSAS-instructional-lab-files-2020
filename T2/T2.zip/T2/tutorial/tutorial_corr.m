
close all;
clear all;
clc;


%global Bscrew Bedge Beclimb Bline 
global Bscrew Bedge Bclimb Bline
totalsteps=100;

appliedstress = zeros(3,3);

mobility='mobfcc0';

t1 = 1/sqrt(6) * [2 1 -1];
t2 = 1/sqrt(6) * [1 1 -2];

L = 2000;

b1 = [  0   1   1  ]/2;
b2 = [  1  -1   0  ]/2;

n1 = [-1 1 -1]/sqrt(3);  
n2 = [ 1 1  1]/sqrt(3);  

% changing line directions
ex = cross(n1,n2);
ex = ex/norm(ex);

e1 = cross(ex,n1);
e2 = cross(ex,n2);

theta1 = 20;
theta2 = 20;


theta1 = theta1*pi/180;
theta2 = theta2*pi/180;


t1 = cos(theta1)*ex + sin(theta1)*e1;
t2 = cos(theta2)*ex + sin(theta2)*e2;

R = cross(t1,t2);
R = R/norm(R);

d = 10;
R = d*R;

rn = [ -t1*L - R 7
        t1*0 - R 0
        t1*L - R 7
       -t2*L + R 7
        t2*0 + R 0
        t2*L + R 7 ];
    
links = [ 1 2   b1 n1
          2 3   b1 n1
          4 5   b2 n2
          5 6   b2 n2 ];

maxconnections=8;
lmax = 1000;
lmin =  200;
a=10;lmin/sqrt(6);
MU = 1.3e11;
NU = 0.309; % for BCC Mo
Ec = MU/(4*pi)*log(a/0.1);

areamin=lmin*lmin*sin(60/180*pi)*0.5; % minimum discretization area
areamax=20*areamin; % maximum discretization area
dt0=1e-5;           %maximum time step
plotfreq=1;       %plot nodes every how many steps
plim=2000;          %plot x,y,z limit (nodes outside not plotted)

viewangle=[60 30];
printfreq=1;      %print out information every how many steps
printnode=1;

integrator='int_trapezoid';

rann = 10;       %annihilation distance (capture radius)
%rntol=1e-1;       %tolerance for integrating equation of motion
rntol = 2*rann;      % on Tom's suggestion
rmax=30;

doremesh    =1;
docollision =1;
doseparation=1;


Bscrew=1e0;
Bedge=1e0;
Bclimb=1e2;
Bline=1.0e-4*min(Bscrew,Bedge);

% % Angle analysis using Kroupa's formula
% 
% theta1tab = linspace(0.1,180,10);
% % theta1 = theta1*180/pi;
% % theta2 = theta2*180/pi;
% 
% for n=1:length(theta1tab)
%     for m=1:length(theta1tab)
%     theta1 = theta1tab(n);
%     theta2 = theta1tab(m);
% 
%     theta1 = theta1*pi/180;
%     theta2 = theta2*pi/180;
% 
% 
%     t1 = cos(theta1)*ex + sin(theta1)*e1;
%     t2 = cos(theta2)*ex + sin(theta2)*e2;
% 
%     F = Kroupa(b1,b2,t1,t2,MU,NU);
%     
%     fprintf('angle =%f F=%f\n',theta1*180/pi,F);
%     end
% end

dd3d


