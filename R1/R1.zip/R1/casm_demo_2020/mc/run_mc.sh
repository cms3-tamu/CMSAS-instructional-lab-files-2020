#!/bin/bash


cd T100
casm monte -s grand_canonical_input.json > out &
cd ../T300
casm monte -s grand_canonical_input.json > out &
cd ../T600
casm monte -s grand_canonical_input.json > out 
